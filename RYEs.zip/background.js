// after install or refresh
console.log('From background.....')